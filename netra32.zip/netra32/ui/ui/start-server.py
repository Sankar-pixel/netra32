import http.server
import socketserver
import os

PORT = 3000
os.chdir(r'c:\Users\priya\Documents\trae_projects\NETRA32\ui')

Handler = http.server.SimpleHTTPRequestHandler

with socketserver.TCPServer(("", PORT), Handler) as httpd:
    print(f"NETRA32 Dashboard running at http://localhost:{PORT}")
    httpd.serve_forever()
