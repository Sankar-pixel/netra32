// API Configuration for WiFi-DensePose UI

// Auto-detect the backend URL from the page origin, but default to port 8000 for our backend
const _origin =
  typeof window !== "undefined" && window.location && window.location.origin
    ? `${window.location.protocol}//${window.location.hostname}:8000`
    : "http://localhost:8000";

export const API_CONFIG = {
  BASE_URL: _origin,
  API_VERSION: "/api/v1",
  WS_PREFIX: "ws://",
  WSS_PREFIX: "wss://",

  // Mock server configuration (only for testing)
  MOCK_SERVER: {
    ENABLED: false, // Set to true only for testing without backend
    AUTO_DETECT: false, // Disabled — sensing tab uses its own WebSocket on :8765
  },

  // API Endpoints
  ENDPOINTS: {
    // Root & Info
    ROOT: "/",
    INFO: "/api/v1/info",
    STATUS: "/api/v1/status",
    METRICS: "/api/v1/metrics",

    // Health
    HEALTH: {
      SYSTEM: "/health/health",
      READY: "/health/ready",
      LIVE: "/health/live",
      METRICS: "/health/metrics",
      VERSION: "/health/version",
    },

    // Pose
    POSE: {
      CURRENT: "/api/v1/pose/current",
      ANALYZE: "/api/v1/pose/analyze",
      ZONE_OCCUPANCY: "/api/v1/pose/zones/{zone_id}/occupancy",
      ZONES_SUMMARY: "/api/v1/pose/zones/summary",
      HISTORICAL: "/api/v1/pose/historical",
      ACTIVITIES: "/api/v1/pose/activities",
      CALIBRATE: "/api/v1/pose/calibrate",
      CALIBRATION_STATUS: "/api/v1/pose/calibration/status",
      STATS: "/api/v1/pose/stats",
    },

    // Streaming
    STREAM: {
      STATUS: "/api/v1/stream/status",
      START: "/api/v1/stream/start",
      STOP: "/api/v1/stream/stop",
      CLIENTS: "/api/v1/stream/clients",
      DISCONNECT_CLIENT: "/api/v1/stream/clients/{client_id}",
      BROADCAST: "/api/v1/stream/broadcast",
      METRICS: "/api/v1/stream/metrics",
      // WebSocket endpoints
      WS_POSE: "/api/v1/stream/pose",
      WS_EVENTS: "/api/v1/stream/events",
    },

    // Development (only in dev mode)
    DEV: {
      CONFIG: "/api/v1/dev/config",
      RESET: "/api/v1/dev/reset",
    },
  },

  // Default request options
  DEFAULT_HEADERS: {
    "Content-Type": "application/json",
    Accept: "application/json",
  },

  // Rate limiting
  RATE_LIMITS: {
    REQUESTS_PER_MINUTE: 60,
    BURST_LIMIT: 10,
  },

  // WebSocket configuration
  WS_CONFIG: {
    RECONNECT_DELAY: 5000,
    MAX_RECONNECT_ATTEMPTS: 5,
    PING_INTERVAL: 30000,
    MESSAGE_TIMEOUT: 10000,
  },
};

// Helper function to build API URLs
export function buildApiUrl(endpoint, params = {}) {
  let url = `${API_CONFIG.BASE_URL}${endpoint}`;

  // Replace path parameters
  Object.keys(params).forEach((key) => {
    if (url.includes(`{${key}}`)) {
      url = url.replace(`{${key}}`, params[key]);
      delete params[key];
    }
  });

  // Add query parameters
  const queryParams = new URLSearchParams(params);
  if (queryParams.toString()) {
    url += `?${queryParams.toString()}`;
  }

  return url;
}

// Helper function to build WebSocket URLs
export function buildWsUrl(endpoint, params = {}) {
  // Match WebSocket protocol to page protocol: https → wss, http → ws.
  // Previous logic forced wss:// on non-localhost HTTP, breaking LAN/Docker
  // deployments served over plain HTTP. See issue #272.
  const isSecure = window.location.protocol === "https:";
  const protocol = isSecure ? API_CONFIG.WSS_PREFIX : API_CONFIG.WS_PREFIX;

  // Derive host from the backend URL (port 8000)
  let host = window.location.hostname; // use same hostname as page
  let url = `${protocol}${host}:8000${endpoint}`;

  // Add query parameters
  const queryParams = new URLSearchParams(params);
  if (queryParams.toString()) {
    url += `?${queryParams.toString()}`;
  }

  return url;
}
