
import requests
response = requests.get("http://localhost:8000/health/health")
print("Status Code:", response.status_code)
print("Response:", response.text)
