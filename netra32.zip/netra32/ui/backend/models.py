
from sqlalchemy import create_engine, Column, Integer, Float, String, DateTime, Boolean, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime, UTC
from pathlib import Path

# SQLite database file (absolute path to current directory)
BASE_DIR = Path(__file__).parent.resolve()
DATABASE_URL = f"sqlite:///{BASE_DIR / 'netra32.db'}?mode=rwc"

engine = create_engine(
    DATABASE_URL, connect_args={"check_same_thread": False},
    poolclass=None
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()


class Node(Base):
    __tablename__ = "nodes"

    id = Column(Integer, primary_key=True, index=True)  # 0-3 for 4 nodes
    name = Column(String, index=True)
    position_x = Column(Float, default=0.0)
    position_y = Column(Float, default=0.0)
    position_z = Column(Float, default=0.0)
    is_active = Column(Boolean, default=True)
    last_seen = Column(DateTime, default=lambda: datetime.now(UTC))


class Telemetry(Base):
    __tablename__ = "telemetry"

    id = Column(Integer, primary_key=True, index=True)
    node_id = Column(Integer, index=True)
    timestamp = Column(DateTime, default=lambda: datetime.now(UTC), index=True)
    rssi = Column(Float)
    csi_data = Column(JSON)  # Store CSI as JSON
    variance = Column(Float, default=0.0)


class Detection(Base):
    __tablename__ = "detections"

    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime, default=lambda: datetime.now(UTC), index=True)
    presence = Column(Boolean, default=False)
    motion_level = Column(String, default="absent")
    confidence = Column(Float, default=0.0)
    person_count = Column(Integer, default=0)


def init_db():
    Base.metadata.create_all(bind=engine)

    # Initialize 4 default nodes
    db = SessionLocal()
    try:
        # Check if nodes already exist
        existing_nodes = db.query(Node).count()
        if existing_nodes == 0:
            # Create 4 nodes with default positions
            default_positions = [
                (-8, 0, -8),
                (8, 0, -8),
                (8, 0, 8),
                (-8, 0, 8)
            ]
            for i in range(4):
                node = Node(
                    id=i,
                    name=f"Node {i}",
                    position_x=default_positions[i][0],
                    position_y=default_positions[i][1],
                    position_z=default_positions[i][2],
                    is_active=True
                )
                db.add(node)
            db.commit()
    finally:
        db.close()
