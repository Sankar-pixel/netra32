
import sys
print("Python version:", sys.version)
try:
    import fastapi
    print("FastAPI version:", fastapi.__version__)
    import uvicorn
    print("Uvicorn version:", uvicorn.__version__)
    from models import init_db
    print("Initializing DB...")
    init_db()
    print("DB initialized successfully!")
    from fastapi.testclient import TestClient
    from main import app
    client = TestClient(app)
    response = client.get("/health/live")
    print("Health check response:", response.status_code, response.json())
    print("All tests passed!")
except Exception as e:
    print("Error:", e)
    import traceback
    traceback.print_exc()
