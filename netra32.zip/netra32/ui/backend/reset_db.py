
from pathlib import Path
from models import init_db, BASE_DIR

# Delete old database files
db_path = BASE_DIR / "netra32.db"
journal_path = BASE_DIR / "netra32.db-journal"

for path in [db_path, journal_path]:
    if path.exists():
        print(f"Deleting {path}")
        path.unlink()

print("Initializing new database...")
init_db()
print("Database initialized successfully!")
