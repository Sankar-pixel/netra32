
import numpy as np
from sklearn.ensemble import IsolationForest
from collections import deque

class AnomalyDetector:
    def __init__(self, max_samples=100):
        self.model = IsolationForest(contamination=0.1, random_state=42)
        self.data_buffer = deque(maxlen=max_samples)
        self.is_trained = False
        
    def add_data(self, features):
        """Add features to buffer (features should be a list/array of numeric values)"""
        self.data_buffer.append(features)
        if len(self.data_buffer) >= 20 and not self.is_trained:
            self.train()
            
    def train(self):
        """Train the model on buffered data"""
        if len(self.data_buffer) < 10:
            return
        X = np.array(self.data_buffer)
        self.model.fit(X)
        self.is_trained = True
        
    def predict(self, features):
        """Predict if features are anomalous (returns True if anomaly)"""
        if not self.is_trained:
            return False
        X = np.array([features])
        prediction = self.model.predict(X)
        return prediction[0] == -1  # -1 means anomaly

# Global anomaly detectors for each node
node_anomaly_detectors = [AnomalyDetector() for _ in range(4)]

def extract_features(telemetry_data):
    """Extract features from telemetry data for anomaly detection"""
    return [
        telemetry_data.get("rssi", -70),
        telemetry_data.get("variance", 0.5),
        np.mean(telemetry_data.get("csi_data", {}).get("amplitude", [0])) if telemetry_data.get("csi_data") else 0
    ]
