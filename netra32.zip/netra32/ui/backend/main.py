
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Depends, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from contextlib import asynccontextmanager
from sqlalchemy.orm import Session
from models import SessionLocal, init_db, Node, Telemetry, Detection
from datetime import datetime, timedelta, UTC
import numpy as np
import json
import random
from pathlib import Path
import asyncio
from ml import node_anomaly_detectors, extract_features

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Initialize database on startup
    init_db()
    # Start simulate data loop (optional, disable temporarily)
    asyncio.create_task(simulate_data_loop())
    yield

app = FastAPI(title="NETRA32 Backend", lifespan=lifespan)

# Dependency to get DB session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# --- Health endpoints ---
@app.get("/health/health")
@app.get("/health/ready")
@app.get("/health/live")
async def health_check():
    return {"status": "ok"}

@app.get("/health/version")
async def get_version():
    return {"version": "1.0.0"}

@app.get("/health/metrics")
async def get_health_metrics(db: Session = Depends(get_db)):
    # Get simple metrics
    node_count = db.query(Node).count()
    telemetry_count = db.query(Telemetry).count()
    return {
        "node_count": node_count,
        "telemetry_count": telemetry_count
    }

# --- API v1 endpoints ---
@app.get("/api/v1/info")
async def get_info():
    return {
        "name": "NETRA32",
        "version": "1.0.0",
        "nodes": 4
    }

@app.get("/api/v1/status")
async def get_status():
    return {"source": "live"}

# --- Node endpoints ---
@app.get("/api/v1/nodes")
async def get_nodes(db: Session = Depends(get_db)):
    nodes = db.query(Node).all()
    return [
        {
            "node_id": node.id,
            "name": node.name,
            "position": [node.position_x, node.position_y, node.position_z],
            "is_active": node.is_active,
            "last_seen": node.last_seen.isoformat() if node.last_seen else None
        }
        for node in nodes
    ]

@app.get("/api/v1/sensing/latest")
async def get_latest_sensing():
    return current_sensing_data

# --- Pose endpoints ---
@app.get("/api/v1/pose/current")
async def get_current_pose():
    return {
        "persons": [],
        "timestamp": datetime.now(UTC).isoformat()
    }

@app.get("/api/v1/pose/stats")
async def get_pose_stats(db: Session = Depends(get_db)):
    total_detections = db.query(Detection).count()
    return {
        "total_detections": total_detections,
        "active_persons": 0,
        "avg_confidence": 0.0
    }

@app.get("/api/v1/pose/zones/summary")
async def get_zones_summary():
    return {
        "zones": []
    }

# --- Streaming endpoints ---
@app.get("/api/v1/stream/status")
async def get_stream_status():
    return {"status": "idle", "clients": len(connected_clients)}

# --- Training/Model endpoints (simple stubs) ---
@app.get("/api/v1/training/status")
async def get_training_status():
    return {"status": "idle"}

@app.get("/api/v1/models")
async def list_models():
    return {"models": []}

@app.get("/api/v1/models/active")
async def get_active_model():
    return {"model": None}

@app.get("/api/v1/recordings")
async def list_recordings():
    return {"recordings": []}

# --- Hardware telemetry endpoint ---
@app.post("/api/hardware/telemetry")
async def receive_telemetry(data: dict, db: Session = Depends(get_db)):
    node_id = data.get("node_id")
    if node_id is None or node_id < 0 or node_id > 3:
        raise HTTPException(status_code=400, detail="Invalid node_id (must be 0-3)")

    is_anomaly = False
    try:
        # Update node last seen
        node = db.query(Node).filter(Node.id == node_id).first()
        if node:
            node.last_seen = datetime.now(UTC)

        # Extract features and add to anomaly detector
        features = extract_features(data)
        node_anomaly_detectors[node_id].add_data(features)
        is_anomaly = node_anomaly_detectors[node_id].predict(features)

        # Save telemetry with anomaly flag
        telemetry = Telemetry(
            node_id=node_id,
            rssi=data.get("rssi", -70),
            csi_data={**data.get("csi_data", {}), "is_anomaly": is_anomaly},
            variance=data.get("variance", 0.5)
        )
        db.add(telemetry)
        db.commit()

        # Update current sensing data
        update_sensing_data(db)

        # Broadcast to WebSocket clients
        await broadcast_sensing_data()
    except Exception as e:
        print(f"DB error in /api/hardware/telemetry: {type(e)} - {e}")
        db.rollback()

    return {"status": "ok", "is_anomaly": is_anomaly}

# --- Store connected WebSocket clients ---
connected_clients = []
pose_connected_clients = []

# --- Global state for current sensing data ---
current_sensing_data = {
    "features": {
        "mean_rssi": -70.0,
        "variance": 0.5,
        "motion_band_power": 0.2,
        "breathing_band_power": 0.1,
        "spectral_power": 1.0,
        "dominant_freq_hz": 0.2,
        "change_points": 3
    },
    "classification": {
        "presence": False,
        "motion_level": "absent",
        "confidence": 0.1
    },
    "nodes": [],
    "node_features": [],
    "signal_field": {
        "values": [0.0] * 400
    },
    "source": "live"
}

# --- WebSocket endpoints ---
@app.websocket("/ws/sensing")
async def websocket_sensing(websocket: WebSocket):
    await websocket.accept()
    connected_clients.append(websocket)
    try:
        await websocket.send_json(current_sensing_data)
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        connected_clients.remove(websocket)

@app.websocket("/api/v1/stream/pose")
async def websocket_pose(websocket: WebSocket):
    await websocket.accept()
    pose_connected_clients.append(websocket)
    try:
        while True:
            await asyncio.sleep(1)
            await websocket.send_json({
                "type": "pose",
                "timestamp": datetime.now(UTC).isoformat(),
                "persons": []
            })
    except WebSocketDisconnect:
        pose_connected_clients.remove(websocket)

# --- Helper functions ---
def update_sensing_data(db: Session):
    global current_sensing_data

    # Get nodes
    nodes = db.query(Node).all()
    
    # Generate node features
    node_features = []
    total_rssi = 0
    total_variance = 0
    
    for node in nodes:
        is_stale = (datetime.now(UTC) - node.last_seen) > timedelta(seconds=10) if node.last_seen else True
        
        latest_telemetry = db.query(Telemetry).filter(
            Telemetry.node_id == node.id
        ).order_by(Telemetry.timestamp.desc()).first()
        
        rssi = latest_telemetry.rssi if latest_telemetry else (-70 + random.uniform(-10, 10))
        variance = latest_telemetry.variance if latest_telemetry else 0.5
        
        total_rssi += rssi
        total_variance += variance
        
        motion_level = "absent"
        confidence = 0.1
        if variance > 0.8:
            motion_level = "active"
            confidence = 0.8
        elif variance > 0.3:
            motion_level = "present"
            confidence = 0.6
        
        node_features.append({
            "node_id": node.id,
            "rssi_dbm": rssi,
            "stale": is_stale,
            "features": {
                "variance": variance
            },
            "classification": {
                "motion_level": motion_level,
                "confidence": confidence
            }
        })
    
    mean_rssi = total_rssi / len(nodes) if nodes else -70
    mean_variance = total_variance / len(nodes) if nodes else 0.5
    
    presence = any(nf["classification"]["motion_level"] != "absent" for nf in node_features)
    motion_level = "active" if any(nf["classification"]["motion_level"] == "active" for nf in node_features) else \
                   "present" if presence else "absent"
    confidence = max(nf["classification"]["confidence"] for nf in node_features) if node_features else 0.1
    
    current_sensing_data = {
        "features": {
            "mean_rssi": mean_rssi,
            "variance": mean_variance,
            "motion_band_power": mean_variance * 0.5,
            "breathing_band_power": 0.1 + random.uniform(-0.02, 0.02),
            "spectral_power": 1.0 + mean_variance,
            "dominant_freq_hz": 0.2 + random.uniform(-0.05, 0.05),
            "change_points": int(mean_variance * 10)
        },
        "classification": {
            "presence": presence,
            "motion_level": motion_level,
            "confidence": confidence
        },
        "nodes": [
            {
                "node_id": node.id,
                "position": [node.position_x, node.position_y, node.position_z]
            }
            for node in nodes
        ],
        "node_features": node_features,
        "signal_field": {
            "values": [mean_variance * random.uniform(0.5, 1.5) for _ in range(400)]
        },
        "source": "live"
    }
    
    detection = Detection(
        presence=presence,
        motion_level=motion_level,
        confidence=confidence,
        person_count=1 if presence else 0
    )
    db.add(detection)
    db.commit()

async def broadcast_sensing_data():
    data_to_send = current_sensing_data.copy()
    for client in connected_clients:
        try:
            await client.send_json(data_to_send)
        except Exception:
            pass

# --- Simulator ---

async def simulate_data_loop():
    while True:
        db = SessionLocal()
        try:
            for node_id in range(4):
                telemetry = Telemetry(
                    node_id=node_id,
                    rssi=-70 + random.uniform(-15, 15),
                    csi_data={"amplitude": [random.random() for _ in range(30)]},
                    variance=0.3 + random.uniform(0, 0.7)
                )
                db.add(telemetry)
            
            db.commit()
            update_sensing_data(db)
            await broadcast_sensing_data()
        except Exception as e:
            print(f"Simulation error: {e}")
        finally:
            db.close()
        
        await asyncio.sleep(0.1)

# --- Mount static files and frontend routes LAST ---
frontend_path = Path(__file__).parent.parent
app.mount("/lib", StaticFiles(directory=str(frontend_path / "lib")), name="lib")
app.mount("/components", StaticFiles(directory=str(frontend_path / "components")), name="components")
app.mount("/services", StaticFiles(directory=str(frontend_path / "services")), name="services")
app.mount("/utils", StaticFiles(directory=str(frontend_path / "utils")), name="utils")
app.mount("/config", StaticFiles(directory=str(frontend_path / "config")), name="config")
app.mount("/pose-fusion", StaticFiles(directory=str(frontend_path / "pose-fusion")), name="pose-fusion")
app.mount("/observatory", StaticFiles(directory=str(frontend_path / "observatory")), name="observatory")
app.mount("/mobile", StaticFiles(directory=str(frontend_path / "mobile")), name="mobile")

# --- Frontend file routes ---
@app.get("/{path:path}")
async def serve_frontend(path: str):
    file_path = frontend_path / path
    if file_path.exists() and file_path.is_file():
        return FileResponse(str(file_path))
    index_path = frontend_path / "index.html"
    return FileResponse(str(index_path))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

