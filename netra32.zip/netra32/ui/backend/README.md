
# NETRA32 Offline Backend

## Quick Start

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Run the backend:
```bash
python main.py
```

3. Open the frontend in your browser at http://localhost:8000

## Features

- 100% offline operation (no internet required!)
- SQLite database for local data storage
- 4-node hardware support
- ML-based anomaly detection
- Real-time WebSocket streaming
- Built-in simulator (no hardware needed to test)

## API Endpoints

- GET /health/health - Health check
- GET /api/v1/nodes - List all nodes
- GET /api/v1/sensing/latest - Get latest sensing data
- POST /api/hardware/telemetry - Send telemetry from a node
- WS /ws/sensing - Real-time sensing stream
- WS /api/v1/stream/pose - Pose stream

## Hardware Integration (ESP32 Nodes)

To send data from an ESP32 node, POST to /api/hardware/telemetry with:

```json
{
  "node_id": 0,
  "rssi": -65,
  "csi_data": {
    "amplitude": [0.5, 0.6, 0.7, ...]
  },
  "variance": 0.6
}
```

node_id must be between 0 and 3!
