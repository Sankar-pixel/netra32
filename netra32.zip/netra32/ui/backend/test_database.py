
from models import init_db, SessionLocal, Node
from datetime import datetime, UTC

print("Calling init_db()")
init_db()
print("Done init_db()")

print("Getting SessionLocal()")
db = SessionLocal()

print("Checking if nodes are present:")
nodes = db.query(Node).all()
print(f"Found {len(nodes)} nodes:")
for node in nodes:
    print(f"  id: {node.id}, name: {node.name}, position: {node.position_x}")

print("\nTrying to update node.last_seen:")
node0 = db.query(Node).filter(Node.id == 0).first()
if node0:
    print(f"  Updating node0.last_seen from {node0.last_seen}")
    node0.last_seen = datetime.now(UTC)
    print("Calling db.commit()")
    db.commit()

    print("Reading back node0.last_seen from DB:")
    node0 = db.query(Node).filter(Node.id == 0).first()
    print(f"  Updated: {node0.last_seen}")

print("\nDone!")
db.close()
