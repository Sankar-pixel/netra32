
import urllib.request
import os

THREEJS_URL = "https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"
OUTPUT_PATH = os.path.join("lib", "three.min.js")

print(f"Downloading Three.js from {THREEJS_URL}...")
try:
    urllib.request.urlretrieve(THREEJS_URL, OUTPUT_PATH)
    print(f"Successfully downloaded Three.js to {OUTPUT_PATH}")
except Exception as e:
    print(f"Error downloading Three.js: {e}")
