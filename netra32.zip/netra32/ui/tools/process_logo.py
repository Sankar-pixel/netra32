
"""
NETRA32 Logo & Favicon Processing Script
Converts logo file to SVG favicon with dark/light mode support
"""
import os
from pathlib import Path

def create_svg_favicon():
    """Create a responsive SVG favicon for NETRA32"""
    svg_content = '''
&lt;svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"&gt;
  &lt;style&gt;
    .netra-logo { fill: #00ff88; }
    @media (prefers-color-scheme: dark) {
      .netra-logo { fill: #00ff88; }
    }
    @media (prefers-color-scheme: light) {
      .netra-logo { fill: #00aa55; }
    }
  &lt;/style&gt;
  &lt;circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" stroke-width="2" class="netra-logo"/&gt;
  &lt;circle cx="50" cy="50" r="20" class="netra-logo"/&gt;
  &lt;circle cx="50" cy="50" r="8" fill="white"/&gt;
  &lt;path d="M30 50 Q50 30 70 50 Q50 70 30 50" fill="none" stroke="currentColor" stroke-width="3" class="netra-logo"/&gt;
&lt;/svg&gt;
    '''.strip()
    
    output_dir = Path(__file__).parent.parent
    output_path = output_dir / "favicon.svg"
    
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(svg_content)
    
    print(f"Created favicon: {output_path}")
    
    # Also update index.html to use the SVG favicon
    index_path = output_dir / "index.html"
    if index_path.exists():
        with open(index_path, "r", encoding="utf-8") as f:
            index_content = f.read()
        
        # Add or update favicon link
        favicon_link = '&lt;link rel="icon" type="image/svg+xml" href="favicon.svg"&gt;'
        
        if favicon_link not in index_content:
            # Insert in head section
            head_end = index_content.find("&lt;/head&gt;")
            if head_end != -1:
                index_content = index_content[:head_end] + favicon_link + "\n" + index_content[head_end:]
                with open(index_path, "w", encoding="utf-8") as f:
                    f.write(index_content)
                print("Updated index.html with favicon")

if __name__ == "__main__":
    create_svg_favicon()
